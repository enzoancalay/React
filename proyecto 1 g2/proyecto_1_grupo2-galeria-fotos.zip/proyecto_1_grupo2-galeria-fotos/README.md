# proyecto_1_grupo2
Movies and series blog
